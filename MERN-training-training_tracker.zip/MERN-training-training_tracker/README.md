# MERN-training
This repository is created for the specific group of people to help them to share the files.
Participants are:
Pruthvi Mohan <pruthvi.mohan@goavega.com>, 
Sujeeth P <sujeeth.p@goavega.com>, 
Nagalaxmi M <nagalaxmi.m@goavega.com>, 
Gulshan Baraik <gulshan.baraik@goavega.com>, 
Rajeshkumar Sivaprakasam <rajesh.kumar@goavega.com>, 
Akshay Patel <akshay.patel@goavega.com>, 
Sneha Singh <sneha.singh@innoserv.co.in>, 
Appugouda Patil <appu.patil@goavega.com>, 
Mahesh Alayil <mahesh.alayil@goavega.com>, 
Anupama Jain <anu.jain@goavega.com>, 
nitish.kumar@goavega.com
