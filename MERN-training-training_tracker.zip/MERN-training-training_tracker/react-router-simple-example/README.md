# react-router-4-example
This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app) and it's the sample project of a beginners guide to [React Router DOM](https://reacttraining.com/react-router/web/guides/philosophy).


## Instructions 
1. Install the dependencies with `npm install`.
2. Execute `npm start` to run the application.

## License
MIT