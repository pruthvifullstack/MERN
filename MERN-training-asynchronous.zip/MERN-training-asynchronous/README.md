# ES6_Training
ES6_Training

Ths is a asynchronous programming.
