var myLogModule = require('./Log.js');
myLogModule.info('This is info level log');
myLogModule.warning('This is warning level log');
myLogModule.error('This is error level log');
