import React from 'react'

const FunctionalExample = (props) => {
  return (
    <div>
      {/* <button onClick={() => props.greetHandler('child')}>Greet Parent</button> */}
      Hello World!
    </div>
  )
}

export default FunctionalExample