var msg = require('./message.js');
console.log(msg);
