var person = require('./person.js');

var person1 = new person('Amit', 'Kumar');

console.log(person1.fullName());
