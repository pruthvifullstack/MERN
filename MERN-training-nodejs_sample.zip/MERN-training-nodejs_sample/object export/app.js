var person = require('./data.js');
console.log('name: ' + person.firstName);
console.log('last name: '+ person.lastName);
console.log('email: ' + person.email);
