module.exports = {
    firstName: 'James',
    lastName: 'Bond',
	email: 'James.bond@gmail.com'
}
