var app = require('./sample');

console.log(app);